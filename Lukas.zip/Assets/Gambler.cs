using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gambler : MonoBehaviour
{
    private bool canGamble = true;
    public GameObject gamblerO; 
    // Start is called before the first frame update
    void Start()
    { 
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1") && canGamble == true && gamblerO.transform.rotation.y == 0)
        {
            Gamble();
            StartCoroutine(GambleCooldown());
        }
    }
    IEnumerator GambleCooldown()
    {
        canGamble = false;
        yield return new WaitForSeconds(3);
        canGamble = true;
    }
    private void Gamble()
    {
        int ovocePicker1 = UnityEngine.Random.Range(0, 10);
        int ovocePicker2 = UnityEngine.Random.Range(0, 10);
        int ovocePicker3 = UnityEngine.Random.Range(0, 10);
        int[] ovocePickers = { ovocePicker1, ovocePicker2, ovocePicker3 };
        for(int i = 0; i < 3; i++)
        {
            switch (ovocePickers[i])
            {
                case 0: Debug.Log("�vestka"); break;
                case 1: Debug.Log("�vestka"); break;
                case 2: Debug.Log("Citr�n"); break;
                case 3: Debug.Log("Citr�n"); break;
                case 4: Debug.Log("T�e�e�"); break;
                case 5: Debug.Log("T�e�e�"); break;
                case 6: Debug.Log("Hrozen"); break;
                case 7: Debug.Log("Sedmi�ka"); break;
                case 8: Debug.Log("Hrozen"); break;
                case 9: Debug.Log("Meloun"); break;
                case 10: Debug.Log("Meloun"); break;
            }
        }
        Debug.Log("-------------------------");
       if(ovocePicker1 == 4 && ovocePicker1 == ovocePicker2 && ovocePicker3 == ovocePicker1)
        {
            Debug.Log("Vyhral jsi");
        }
        
    }
}
